# Student_Evaluation_System
This is a FULL STACK JAVA project made using SpringBoot and MySQL database .
